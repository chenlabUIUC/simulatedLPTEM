ArrayXd v = ArrayXd::LinSpaced(7,-2,2);
cout << v << endl << endl;
cout << ceil(v) << endl;
